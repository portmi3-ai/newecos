module.exports = {
  testMatch: ['**/tests/**/*.test.js'],
}; 