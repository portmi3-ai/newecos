import metaAgentOrchestrator from '../services/metaAgentOrchestrator.js';

export const createMetaAgent = async (req, res) => {
  try {
    const userId = req.user.sub;
    const command = { ...req.body, userId };
    const result = await metaAgentOrchestrator.createMetaAgent(command);
    res.status(201).json(result);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const createAdvisorAgentTeam = async (req, res) => {
  try {
    const userId = req.user.sub;
    const deploy = req.body.deploy !== false; // default true
    const result = await metaAgentOrchestrator.createAdvisorAgentTeam({ userId, deploy });
    res.status(201).json(result);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
}; 