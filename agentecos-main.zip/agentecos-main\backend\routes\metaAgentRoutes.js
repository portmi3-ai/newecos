import express from 'express';
import { checkJwt } from '../middleware/authMiddleware.js';
import { createMetaAgent, createAdvisorAgentTeam } from '../controllers/metaAgentController.js';

const router = express.Router();

router.post('/', checkJwt, createMetaAgent);
router.post('/advisor-team', checkJwt, createAdvisorAgentTeam);

export default router; 